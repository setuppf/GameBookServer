See `../README.md` for details on how to build for iOS.

