---
title: "mg_set_protocol_coap()"
decl_name: "mg_set_protocol_coap"
symbol_kind: "func"
signature: |
  int mg_set_protocol_coap(struct mg_connection *nc);
---

Sets CoAP protocol handler - triggers CoAP specific events. 

