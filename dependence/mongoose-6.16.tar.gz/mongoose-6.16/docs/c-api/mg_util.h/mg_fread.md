---
title: "mg_fread()"
decl_name: "mg_fread"
symbol_kind: "func"
signature: |
  size_t mg_fread(void *ptr, size_t size, size_t count, FILE *f);
---

Reads data from the given file stream.

Return value is a number of bytes readen. 

