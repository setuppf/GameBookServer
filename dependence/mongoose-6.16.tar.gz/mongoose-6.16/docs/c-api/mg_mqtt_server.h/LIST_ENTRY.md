---
title: "LIST_ENTRY()"
decl_name: "LIST_ENTRY"
symbol_kind: "func"
signature: |
    LIST_ENTRY(mg_mqtt_session);
---

Broker 

