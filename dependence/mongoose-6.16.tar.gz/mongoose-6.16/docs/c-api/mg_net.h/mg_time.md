---
title: "mg_time()"
decl_name: "mg_time"
symbol_kind: "func"
signature: |
  double mg_time(void);
---

A sub-second precision version of time(). 

