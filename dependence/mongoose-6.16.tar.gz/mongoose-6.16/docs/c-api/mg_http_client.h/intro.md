---
title: "Client API reference"
symbol_kind: "intro"
decl_name: "mg_http_client.h"
items:
  - { name: mg_connect_http.md }
  - { name: mg_connect_http_opt.md }
  - { name: mg_http_create_digest_auth_header.md }
---



